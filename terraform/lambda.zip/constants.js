"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COLORS = exports.WorkflowState = void 0;
var WorkflowState;
(function (WorkflowState) {
    WorkflowState["started"] = "started";
    WorkflowState["preMigration"] = "preMigration";
    WorkflowState["deploying"] = "deploying";
    WorkflowState["waitingForStabilization"] = "waitingForStabilization";
    WorkflowState["postMigration"] = "postMigration";
    WorkflowState["finished"] = "finished";
    WorkflowState["stopped"] = "stopped";
    WorkflowState["failed"] = "failed";
    WorkflowState["skipped"] = "skipped";
})(WorkflowState = exports.WorkflowState || (exports.WorkflowState = {}));
exports.COLORS = {
    normal: "#888888",
    info: "#28A0F0",
    success: "#45CC88",
    warning: "#F1C45E",
    error: "#FF676A",
    slackGood: "good",
    slackDanger: "danger",
    slackWarning: "warning",
};
