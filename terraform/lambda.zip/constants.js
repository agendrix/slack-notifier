"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COLORS = exports.PipelineState = void 0;
var PipelineState;
(function (PipelineState) {
    PipelineState["started"] = "started";
    PipelineState["preMigration"] = "preMigration";
    PipelineState["deploying"] = "deploying";
    PipelineState["waitingForStabilization"] = "waitingForStabilization";
    PipelineState["postMigration"] = "postMigration";
    PipelineState["finished"] = "finished";
    PipelineState["stopped"] = "stopped";
    PipelineState["failed"] = "failed";
})(PipelineState = exports.PipelineState || (exports.PipelineState = {}));
exports.COLORS = {
    normal: "#888888",
    info: "#28A0F0",
    success: "#45CC88",
    warning: "#F1C45E",
    error: "#FF676A",
    slackGood: "good",
    slackDanger: "danger",
    slackWarning: "warning"
};
