"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callApi = void 0;
const request_1 = __importDefault(require("request"));
const env_1 = require("./env");
async function callApi(method, options) {
    const url = `https://slack.com/api/${method}`;
    const slackRequest = {
        url,
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${env_1.SLACK_CONFIG.accessToken}`,
        },
        json: options,
    };
    return new Promise(function (resolve, reject) {
        request_1.default(slackRequest, function (error, _res, body) {
            if (!error && body.ok) {
                resolve(body);
            }
            else {
                reject(`Error while calling "${url}":\n${error || body}`);
            }
        });
    });
}
exports.callApi = callApi;
