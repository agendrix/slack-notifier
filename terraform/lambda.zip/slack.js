"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.callApi = void 0;
const request_1 = __importDefault(require("request"));
const env_1 = require("./env");
async function callApi(method, options) {
    const url = `https://slack.com/api/${method}`;
    const slackRequest = {
        url,
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${env_1.SLACK_ACCESS_TOKEN}`
        },
        json: options
    };
    return new Promise(function (resolve, reject) {
        request_1.default(slackRequest, function (error, res, body) {
            if (!error && res.statusCode == 200) {
                if (body.ok) {
                    resolve(body);
                }
                else {
                    reject(`Error while calling "${url}":\n${body}`);
                }
            }
            else {
                reject(`Error while calling "${url}":\n${error}`);
            }
        });
    });
}
exports.callApi = callApi;
