"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GithubWrapper = void 0;
const github_api_1 = __importDefault(require("github-api"));
const env_1 = require("./env");
class GithubWrapper {
    constructor(repoInfo) {
        this.repoInfo = repoInfo;
        const gh = new github_api_1.default({ token: env_1.GITHUB_TOKEN });
        this.repo = gh.getRepo(repoInfo.owner, repoInfo.name);
    }
    async getHeadCommit() {
        const ref = await this.repo.getRef(`heads/${this.repoInfo.branch}`);
        if (ref.status !== 200) {
            throw new Error(`Error while fetching latest commit on branch ${this.repoInfo.branch} from ${this.repoInfo.owner}/${this.repoInfo.name}.`);
        }
        const sha = ref.data.object.sha;
        if (!sha)
            throw new Error(`Head commit not found.\nEvent:\n${JSON.stringify(event)}`);
        return sha;
    }
    async compareCommits(base, head) {
        const compare = await this.repo.compareBranches(base || head, head);
        if (compare.status !== 200) {
            throw new Error(`Error while fetching changelog from GitHub (${base}...${head}).`);
        }
        const refCommit = compare.data.commits.length === 0
            ? compare.data.base_commit
            : compare.data.commits[compare.data.commits.length - 1];
        const authorName = refCommit.commit.author.name;
        const changelog = compare.data.commits.map(commit => {
            const commitMessage = commit.commit.message.split("\n")[0];
            const cleanedMessaged = this.replace(this.replace(commitMessage, "<", "«"), ">", "»");
            const commitUrl = commit.html_url;
            return `<${commitUrl}|${cleanedMessaged}>`;
        });
        return {
            authorName,
            changelog,
            totalCommits: compare.data.total_commits,
            compareUrl: compare.data.html_url,
        };
    }
    replace(str, search, replacement) {
        return str.split(search).join(replacement);
    }
}
exports.GithubWrapper = GithubWrapper;
