"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GithubWrapper = void 0;
const env_1 = require("./env");
const rest_1 = require("@octokit/rest");
const SHORT_SHA_LENGTH = 7;
class GithubWrapper {
    constructor(repo) {
        this.repo = repo;
        this.octokit = new rest_1.Octokit({ auth: env_1.GITHUB_TOKEN });
    }
    async getHeadCommit(branchName) {
        const branch = await this.octokit.repos.getBranch({
            branch: branchName,
            repo: this.repo.name,
            owner: this.repo.owner,
        });
        if (branch.status !== 200) {
            throw this.makeError(`Error while fetching latest commit on branch ${branchName}`);
        }
        return branch.data.commit.sha;
    }
    async compareCommits(base, head) {
        const compare = await this.octokit.repos.compareCommits({
            base: (base || head).substr(0, SHORT_SHA_LENGTH),
            head: head.substr(0, SHORT_SHA_LENGTH),
            owner: this.repo.owner,
            repo: this.repo.name,
        });
        if (compare.status !== 200) {
            throw this.makeError(`Error while fetching changelog from GitHub (${base}...${head}).`);
        }
        const refCommit = compare.data.commits.length === 0
            ? compare.data.base_commit
            : compare.data.commits[compare.data.commits.length - 1];
        const authorName = refCommit.commit.author.name;
        const changelog = compare.data.commits.map(commit => {
            const commitMessage = commit.commit.message.split("\n")[0];
            const cleanedMessaged = commitMessage.replace(/</g, "«").replace(/>/g, "»");
            const commitUrl = commit.html_url;
            return `<${commitUrl}|${cleanedMessaged}>`;
        });
        return {
            authorName,
            changelog,
            totalCommits: compare.data.total_commits,
            compareUrl: compare.data.html_url,
        };
    }
    makeError(message) {
        return new Error(`${message}\nRepo: ${this.repo.owner}/${this.repo.name}`);
    }
}
exports.GithubWrapper = GithubWrapper;
