"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CODEPIPELINE_CONFIG = exports.API_SECRET = exports.S3_CONFIG = exports.SLACK_CONFIG = exports.REPO = exports.GITHUB_TOKEN = exports.ENV = void 0;
exports.ENV = process.env.ENV;
exports.GITHUB_TOKEN = process.env.GITHUB_TOKEN;
exports.REPO = JSON.parse(process.env.REPO);
exports.SLACK_CONFIG = JSON.parse(process.env.S3_CONFIG);
exports.S3_CONFIG = JSON.parse(process.env.S3_CONFIG);
exports.API_SECRET = process.env.API_SECRET;
exports.CODEPIPELINE_CONFIG = process.env.CODEPIPELINE_CONFIG
    ? JSON.parse(process.env.CODEPIPELINE_CONFIG)
    : undefined;
