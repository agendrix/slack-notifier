# Slack Notifier

_An AWS Lambda for sending deployment updates to Slack._
_Supports GitHub Actions and CodePipeline deployments._

![Tests](https://github.com/agendrix/slack-notifier/workflows/Tests/badge.svg?branch=main)

TODO
