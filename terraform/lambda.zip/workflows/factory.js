"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWorkflow = exports.isSupportedHTTPLambdaRequest = void 0;
const env_1 = require("../env");
const code_pipeline_1 = require("./code-pipeline");
const github_actions_1 = require("./github-actions");
function isSupportedHTTPLambdaRequest(event) {
    var _a;
    return event.body && event.httpMethod === "POST" && ((_a = event === null || event === void 0 ? void 0 : event.headers) === null || _a === void 0 ? void 0 : _a["Content-Type"]) === "application/json";
}
exports.isSupportedHTTPLambdaRequest = isSupportedHTTPLambdaRequest;
exports.getWorkflow = (event) => {
    if (isSupportedHTTPLambdaRequest(event)) {
        const bodyEvent = JSON.parse(event.body);
        if (github_actions_1.GithubActionsWorkflow.isEventSupported(bodyEvent)) {
            return new github_actions_1.GithubActionsWorkflow(bodyEvent, env_1.REPO);
        }
    }
    else if (code_pipeline_1.CodePipelineWorkflow.isEventSupported(event)) {
        return new code_pipeline_1.CodePipelineWorkflow(event, env_1.REPO);
    }
    return undefined;
};
