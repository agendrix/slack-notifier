"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GithubActionsWorkflow = void 0;
const constants_1 = require("../constants");
const workflow_1 = require("./workflow");
const GH_ACTIONS_EXECUTION_STATES = {
    STARTED: constants_1.PipelineState.started,
    PRE_MIGRATIONS: constants_1.PipelineState.preMigration,
    DEPLOYING: constants_1.PipelineState.deploying,
    POST_MIGRATIONS: constants_1.PipelineState.postMigration,
    STOPPED: constants_1.PipelineState.stopped,
    FAILED: constants_1.PipelineState.failed,
    SUCCEEDED: constants_1.PipelineState.finished,
};
class GithubActionsWorkflow extends workflow_1.Workflow {
    static isEventSupported(event) {
        return event.source === "github.actions";
    }
    constructor(event, repo) {
        super(event, repo);
        console.log(`Event captured:\ndetailType: GitHub Actions Event\nstate: ${event.state}`);
    }
    getExecutionUrl() {
        return {
            title: "View Pipeline in GitHub Actions",
            url: `https://github.com/${this.repo.owner}/${this.repo.name}/actions/runs/${this.event.githubRunId}`,
        };
    }
    getExecutionState() {
        return GH_ACTIONS_EXECUTION_STATES[this.event.state];
    }
    async getExecutionId() {
        return new Promise(resolve => resolve(this.event.githubRunId));
    }
    async getExecutionCommitSha() {
        return new Promise(resolve => resolve(this.event.githubSha));
    }
    async getLatestDeployedCommitSha() {
        return this.event.previousSha || undefined;
    }
}
exports.GithubActionsWorkflow = GithubActionsWorkflow;
