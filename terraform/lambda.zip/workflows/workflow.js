"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Workflow = void 0;
const constants_1 = require("../constants");
const github_1 = require("../github");
const aws = __importStar(require("../aws"));
const MAX_NUMBER_OF_COMMITS_TO_SHOW = 40;
class Workflow {
    constructor(event, repo) {
        this.event = event;
        this.repo = repo;
    }
    async getSlackMessageData() {
        if (this.getExecutionState() === constants_1.PipelineState.started) {
            return this.getFirstSlackMessageData();
        }
        try {
            const pipelines = await aws.loadPipelines();
            return pipelines[await this.getExecutionId()];
        }
        catch (error) {
            console.error(error);
            return undefined;
        }
    }
    truncateChangelog(changelog, compareUrl) {
        return [...changelog.slice(0, MAX_NUMBER_OF_COMMITS_TO_SHOW - 1), `<${compareUrl}|And more...>`].join("\n");
    }
    getChangelogText({ changelog, totalCommits, compareUrl, }) {
        if (changelog.length === 0)
            return { text: "No code change" };
        return {
            text: changelog.length <= MAX_NUMBER_OF_COMMITS_TO_SHOW
                ? changelog.join("\n")
                : this.truncateChangelog(changelog, compareUrl),
            footer: `<${compareUrl}|${totalCommits} new ${totalCommits > 1 ? "commits" : "commit"}>`,
        };
    }
    async getFirstSlackMessageData() {
        const github = new github_1.GithubWrapper(this.repo);
        const commitSha = await this.getExecutionCommitSha(github);
        const baseCommit = await this.getLatestDeployedCommitSha();
        const comparison = await github.compareCommits(baseCommit, commitSha);
        const { title, url } = this.getExecutionUrl();
        const executionId = await this.getExecutionId();
        return {
            executionId,
            messageDetails: Object.assign({ ts: Date.now(), pretext: `<${url}|${title}>` }, this.getChangelogText(comparison)),
        };
    }
}
exports.Workflow = Workflow;
