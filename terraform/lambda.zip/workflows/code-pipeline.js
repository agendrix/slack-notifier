"use strict";
var __createBinding =
  (this && this.__createBinding) ||
  (Object.create
    ? function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        Object.defineProperty(o, k2, {
          enumerable: true,
          get: function () {
            return m[k];
          },
        });
      }
    : function (o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
      });
var __setModuleDefault =
  (this && this.__setModuleDefault) ||
  (Object.create
    ? function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
      }
    : function (o, v) {
        o["default"] = v;
      });
var __importStar =
  (this && this.__importStar) ||
  function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null)
      for (var k in mod)
        if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
  };
Object.defineProperty(exports, "__esModule", { value: true });
exports.CodePipelineWorkflow = void 0;
const constants_1 = require("../constants");
const workflow_1 = require("./workflow");
const aws = __importStar(require("../aws"));
const env_1 = require("../env");
function isCodePipelineEvent(event) {
  return event.source === "aws.codepipeline";
}
function isCodeDeployEvent(event) {
  return event.source === "aws.codedeploy";
}
class CodePipelineWorkflow extends workflow_1.Workflow {
  constructor(event, repo) {
    super(event, repo);
    if (!env_1.ECR_REF_REPOSITORY) throw new Error("ECR_REF_REPOSITORY is required for CodePipeline deployment.");
    if (!env_1.PIPELINE_NAME) throw new Error("PIPELINE_NAME is required for CodePipeline deployment.");
    this.ecrRefRepository = env_1.ECR_REF_REPOSITORY;
    this.pipelineName = env_1.PIPELINE_NAME;
    console.log(`Event captured:\ndetailType: ${event["detail-type"]}\nstate: ${event.detail.state}`);
  }
  static isEventSupported(event) {
    return isCodePipelineEvent(event) || isCodeDeployEvent(event);
  }
  getExecutionUrl() {
    if (!isCodePipelineEvent(this.event)) throw new Error("Cannot get execution URL from CodeDeploy events.");
    return {
      title: "View Pipeline in AWS",
      url: `https://ca-central-1.console.aws.amazon.com/codesuite/codepipeline/pipelines/${this.event.detail.pipeline}/executions/${this.event.detail["execution-id"]}/timeline?region=${this.event.region}`,
    };
  }
  getExecutionState() {
    if (isCodePipelineEvent(this.event)) {
      switch (this.event.detail.state) {
        case "STARTED":
          return constants_1.PipelineState.started;
        case "STOPPED":
          return constants_1.PipelineState.stopped;
        case "FAILED":
          return constants_1.PipelineState.failed;
        case "SUCCEEDED": // Ignore Pipeline succeeded as it is handled by CodeDeploy.
        case "SUPERSEDED":
        case "STOPPING":
        default:
          return undefined;
      }
    } else if (isCodeDeployEvent(this.event)) {
      switch (this.event.detail.state) {
        case "START":
          if (this.event["detail-type"] === "CodeDeploy Deployment State-change Notification") {
            return constants_1.PipelineState.deploying;
          }
          break;
        case "SUCCESS":
          if (this.event["detail-type"] === "CodeDeploy Instance State-change Notification") {
            return constants_1.PipelineState.waitingForStabilization;
          } else if (this.event["detail-type"] === "CodeDeploy Deployment State-change Notification") {
            return constants_1.PipelineState.finished;
          }
          break;
        case "READY":
        case "FAILURE": // Will be handled by the CodePipeline.
        default:
          break;
      }
    }
    return undefined;
  }
  async getExecutionId() {
    if (this.currentExecutionId) {
      return this.currentExecutionId;
    }
    const pipelines = await aws.loadPipelines();
    let executionId;
    if (isCodePipelineEvent(this.event)) {
      executionId = this.event.detail["execution-id"];
    } else if (isCodeDeployEvent(this.event)) {
      executionId = await aws.findPipelineExecutionId(this.pipelineName, pipelines, this.event.detail.deploymentId);
    }
    if (!executionId) throw new Error(`Execution id not found for pipeline '${this.pipelineName}'.`);
    this.currentExecutionId = executionId;
    return this.currentExecutionId;
  }
  async getExecutionCommitSha(github) {
    return github.getHeadCommit();
  }
  async getLatestDeployedCommitSha() {
    return aws.getLatestDeployedCommitShaFromECR(this.ecrRefRepository);
  }
}
exports.CodePipelineWorkflow = CodePipelineWorkflow;
