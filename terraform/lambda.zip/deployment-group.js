"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = exports.handleDeploymentGroupEvent = exports.isDeploymentGroupEvent = void 0;
const slack = __importStar(require("./slack"));
const constants_1 = require("./constants");
const env_1 = require("./env");
const github_1 = require("./github");
const EVENT_TYPE = "deployment_group";
const SHORT_SHA_LENGTH = 7;
const MAX_COMMITS_TO_SHOW = 5;
const MAX_UPDATE_ATTEMPTS = 3;
const HISTORY_LIMIT = 100;
const TIME_ZONE = "America/Toronto";
const COLORS_BY_STATUS = {
    inProgress: constants_1.COLORS.warning,
    succeeded: constants_1.COLORS.success,
    failed: constants_1.COLORS.error,
    skipped: constants_1.COLORS.normal,
};
const STEP_LABELS = {
    STARTED: "Started",
    PRE_MIGRATIONS: "Pre-migrations",
    DEPLOYING: "Deploying",
    POST_MIGRATIONS: "Post-migrations",
};
const FAILED_STEP_LABELS = Object.assign(Object.assign({}, STEP_LABELS), { STARTED: "Build" });
const ENDING_STATES = ["SUCCEEDED", "FAILED", "STOPPED", "SKIPPED"];
/** The team follows production deploys; the other groups only show up in Slack when one of their deploys fails. */
const isQuietGroup = (group) => group !== "production";
const RELEASE_STATES = {
    RELEASE_PUBLISHED: "published",
    RELEASE_SKIPPED: "skipped",
    RELEASE_FAILED: "failed",
};
const shortSha = (sha) => sha.substr(0, SHORT_SHA_LENGTH);
const pluralize = (count, word) => `${count} ${word}${count === 1 ? "" : "s"}`;
const formatTime = (at) => new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
}).format(new Date(at));
const getRunUrl = (event) => `https://github.com/${env_1.REPO.owner}/${env_1.REPO.name}/actions/runs/${event.githubRunId}`;
const getGroupKey = (event) => `${env_1.REPO.owner}/${env_1.REPO.name}/${event.githubSha}/${event.group}`;
async function listGroupMessages() {
    const history = await slack.callApi("conversations.history", {
        channel: env_1.SLACK_CONFIG.channel,
        limit: HISTORY_LIMIT,
        include_all_metadata: true,
    });
    return (history.messages || [])
        .filter((message) => { var _a; return ((_a = message.metadata) === null || _a === void 0 ? void 0 : _a.event_type) === EVENT_TYPE; })
        .map((message) => ({ ts: message.ts, payload: message.metadata.event_payload }))
        .sort((a, b) => parseFloat(a.ts) - parseFloat(b.ts));
}
async function findGroupMessage(key) {
    return (await listGroupMessages()).find(message => message.payload.key === key);
}
const waitForOtherWriters = () => new Promise(resolve => setTimeout(resolve, env_1.SETTLE_DELAY_MS * (0.5 + Math.random())));
async function findReplacingSha(message) {
    const newer = (await listGroupMessages()).find(other => other.payload.group === message.payload.group &&
        other.payload.key !== message.payload.key &&
        parseFloat(other.ts) > parseFloat(message.ts));
    return newer === null || newer === void 0 ? void 0 : newer.payload.sha;
}
async function createGroupMessage(event, key) {
    const github = new github_1.GithubWrapper(env_1.REPO);
    const { changelog, totalCommits, compareUrl } = await github.compareCommits(event.previousSha, event.githubSha);
    const payload = {
        key,
        sha: event.githubSha,
        group: event.group,
        initiator: event.initiator,
        changelog: changelog.slice(0, MAX_COMMITS_TO_SHOW),
        totalCommits,
        compareUrl,
        envs: {},
    };
    const posted = await slack.callApi("chat.postMessage", Object.assign({ channel: env_1.SLACK_CONFIG.channel }, renderGroupMessage(payload)));
    const earliest = await findGroupMessage(key);
    if (earliest && earliest.ts !== posted.ts) {
        await slack.callApi("chat.delete", { channel: env_1.SLACK_CONFIG.channel, ts: posted.ts });
        return earliest;
    }
    return { ts: posted.ts, payload };
}
function buildChange(event, failedStep, replacedBy) {
    const releaseState = RELEASE_STATES[event.state];
    if (releaseState) {
        const release = releaseState === "published"
            ? { state: releaseState, name: event.releaseName, url: event.releaseUrl }
            : { state: releaseState, runUrl: getRunUrl(event) };
        return payload => (Object.assign(Object.assign({}, payload), { release }));
    }
    const environmentState = Object.assign({ state: event.state, at: Date.now(), runUrl: getRunUrl(event) }, (event.state === "FAILED" ? { failedStep } : {}));
    return payload => (Object.assign(Object.assign(Object.assign({}, payload), (replacedBy ? { replacedBy } : {})), { envs: Object.assign(Object.assign({}, payload.envs), { [env_1.ENV]: environmentState }) }));
}
function isChangeSaved(saved, expected, event) {
    var _a, _b;
    if (RELEASE_STATES[event.state])
        return ((_a = saved.release) === null || _a === void 0 ? void 0 : _a.state) === ((_b = expected.release) === null || _b === void 0 ? void 0 : _b.state);
    const savedState = saved.envs[env_1.ENV];
    const expectedState = expected.envs[env_1.ENV];
    return (savedState === null || savedState === void 0 ? void 0 : savedState.state) === expectedState.state && (savedState === null || savedState === void 0 ? void 0 : savedState.at) === expectedState.at;
}
async function getMention(event) {
    if (event.initiatorEmail) {
        try {
            const response = await slack.callApi("users.lookupByEmail", { email: event.initiatorEmail });
            return `<@${response.user.id}>`;
        }
        catch (error) {
            console.error(error);
        }
    }
    return event.initiator ? `@${event.initiator}` : "";
}
function renderFailureReply(event, failedStep, mention) {
    const runLink = `<${getRunUrl(event)}|Open the run>`;
    const step = failedStep ? ` at *${failedStep}*` : "";
    const reason = event.state === "RELEASE_FAILED" ? "❌ Release failed." : `❌ *${env_1.ENV}* failed${step}.`;
    return [reason, [runLink, mention].filter(Boolean).join(" · ")].join(" ");
}
async function postFailureReply(event, messageTs, failedStep) {
    await slack.callApi("chat.postMessage", {
        channel: env_1.SLACK_CONFIG.channel,
        thread_ts: messageTs,
        text: renderFailureReply(event, failedStep, await getMention(event)),
    });
}
function getGroupStatus(payload) {
    const states = Object.values(payload.envs).map(environment => environment.state);
    if (states.some(state => state === "FAILED" || state === "STOPPED"))
        return "failed";
    if (states.length === 0 || states.some(state => !ENDING_STATES.includes(state)))
        return "inProgress";
    if (states.every(state => state === "SKIPPED"))
        return "skipped";
    return "succeeded";
}
function renderTitle(payload, status) {
    const environments = Object.values(payload.envs);
    const sha = `<https://github.com/${env_1.REPO.owner}/${env_1.REPO.name}/commit/${payload.sha}|${shortSha(payload.sha)}>`;
    const done = environments.filter(environment => environment.state === "SUCCEEDED").length;
    const failed = environments.filter(environment => environment.state === "FAILED").length;
    const progress = `${done}/${environments.length} done${failed > 0 ? `, ${failed} failed` : ""}`;
    const isEnded = environments.length > 0 && environments.every(environment => ENDING_STATES.includes(environment.state));
    if (status === "skipped") {
        const reason = payload.replacedBy ? `replaced by \`${shortSha(payload.replacedBy)}\`` : "nothing to deploy";
        return `⏭️ Skipped ${sha} on *${payload.group}* · ${reason}`;
    }
    if (!isEnded)
        return `:loading_fast: Deploying ${sha} to *${payload.group}* · ${progress}`;
    if (status === "failed")
        return `❌ Deployed ${sha} to *${payload.group}* · ${progress}`;
    return `✅ Deployed ${sha} to *${payload.group}*`;
}
function renderEnvironment(name, environment) {
    const failedStep = environment.failedStep ? ` at ${environment.failedStep}` : "";
    const lines = {
        SUCCEEDED: ["✅", "Finished"],
        FAILED: ["❌", `Failed${failedStep}`],
        STOPPED: ["⏹️", "Stopped"],
        SKIPPED: ["⏭️", "Skipped"],
    };
    const [emoji, step] = lines[environment.state] || [":loading-blue:", STEP_LABELS[environment.state]];
    return `• ${emoji} <${environment.runUrl}|*${name}*> · ${formatTime(environment.at)}: ${step}`;
}
function renderRelease(release) {
    const lines = {
        published: `📦 Release <${release.url}|*${release.name}*>`,
        skipped: "📦 No new release",
        failed: `📦 Release failed · <${release.runUrl}|Open the run>`,
    };
    return lines[release.state];
}
function renderCommitsCount(payload, isListed) {
    if (payload.totalCommits === 0)
        return "No code change";
    return `<${payload.compareUrl}|${pluralize(payload.totalCommits, isListed ? "new commit" : "commit")}>`;
}
function renderCommits(payload) {
    const hidden = payload.totalCommits - payload.changelog.length;
    return [...payload.changelog, ...(hidden > 0 ? [`<${payload.compareUrl}|+${hidden} more>`] : [])];
}
function renderGroupMessage(payload) {
    var _a;
    const status = getGroupStatus(payload);
    const isCommitListed = ((_a = payload.release) === null || _a === void 0 ? void 0 : _a.state) !== "published";
    const initiatorLabel = payload.group === "production" ? "launched by" : "merged by";
    /** Slack renders the footer as small grey text, with links but without bold. */
    const footer = [
        renderCommitsCount(payload, isCommitListed),
        ...(payload.initiator ? [`${initiatorLabel} @${payload.initiator}`] : []),
    ].join(" · ");
    const lines = [
        ...(isCommitListed ? renderCommits(payload) : []),
        ...(payload.release ? [renderRelease(payload.release)] : []),
        ...Object.keys(payload.envs)
            .sort()
            .map(name => renderEnvironment(name, payload.envs[name])),
    ];
    return {
        text: renderTitle(payload, status),
        attachments: [{ color: COLORS_BY_STATUS[status], text: lines.join("\n"), footer, mrkdwn_in: ["text"] }],
        metadata: { event_type: EVENT_TYPE, event_payload: payload },
    };
}
function isDeploymentGroupEvent(event) {
    return !!event.group;
}
exports.isDeploymentGroupEvent = isDeploymentGroupEvent;
async function handleDeploymentGroupEvent(event) {
    const key = getGroupKey(event);
    const existing = await findGroupMessage(key);
    const isQuiet = isQuietGroup(event.group);
    if (!existing && isQuiet && event.state !== "FAILED")
        return;
    let message = existing || (await createGroupMessage(event, key));
    const previous = message.payload.envs[env_1.ENV];
    // A quiet group keeps no message before its first failure, so the step that failed is unknown there.
    const failedStep = previous || !isQuiet ? FAILED_STEP_LABELS[(previous === null || previous === void 0 ? void 0 : previous.state) || "STARTED"] : undefined;
    const replacedBy = event.state === "SKIPPED" ? await findReplacingSha(message) : undefined;
    const applyChange = buildChange(event, failedStep, replacedBy);
    for (let attempt = 0; attempt < MAX_UPDATE_ATTEMPTS; attempt++) {
        const payload = applyChange(message.payload);
        await slack.callApi("chat.update", Object.assign({ channel: env_1.SLACK_CONFIG.channel, ts: message.ts }, renderGroupMessage(payload)));
        let saved = await findGroupMessage(key);
        // Slack has no conditional update: an environment that read the message before this write can still overwrite it.
        if (saved && isChangeSaved(saved.payload, payload, event)) {
            await waitForOtherWriters();
            saved = await findGroupMessage(key);
        }
        if (!saved || isChangeSaved(saved.payload, payload, event))
            break;
        message = saved;
    }
    const isNewEnvironmentFailure = event.state === "FAILED" && (previous === null || previous === void 0 ? void 0 : previous.state) !== "FAILED";
    if (isNewEnvironmentFailure || event.state === "RELEASE_FAILED") {
        await postFailureReply(event, message.ts, failedStep);
    }
}
exports.handleDeploymentGroupEvent = handleDeploymentGroupEvent;
exports.__test__ = {
    renderGroupMessage,
    renderFailureReply,
    COLORS_BY_STATUS,
};
