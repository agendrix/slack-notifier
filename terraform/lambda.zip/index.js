"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws = __importStar(require("./aws"));
const slack = __importStar(require("./slack"));
const constants_1 = require("./constants");
const env_1 = require("./env");
const factory_1 = require("./workflows/factory");
// prettier-ignore
const STATE_MESSAGES = {
    started: [constants_1.COLORS.normal, ref => `Started deploying ${ref}`],
    preMigration: [constants_1.COLORS.info, ref => `Started deploying ${ref} (Pre-migrations)`],
    deploying: [constants_1.COLORS.info, ref => `Started deploying ${ref} (Updating servers)`],
    waitingForStabilization: [constants_1.COLORS.info, ref => `Started deploying ${ref} (Waiting for stabilization)`],
    postMigration: [constants_1.COLORS.info, ref => `Started deploying ${ref} (Post-migrations)`],
    finished: [constants_1.COLORS.success, ref => `*Finished* deploying ${ref}`],
    stopped: [constants_1.COLORS.error, ref => `Deployment *stopped* for ${ref}`],
    failed: [constants_1.COLORS.error, ref => `Deployment *failed* for ${ref}`],
};
const ENDING_STATES = [constants_1.WorkflowState.finished, constants_1.WorkflowState.stopped, constants_1.WorkflowState.failed];
let lambdaCallback = undefined;
function sendResponse(message, statusCode) {
    const response = {
        statusCode,
        body: message,
        headers: { "Content-Type": "text/html; charset=utf-8" },
        isBase64Encoded: false,
    };
    lambdaCallback === null || lambdaCallback === void 0 ? void 0 : lambdaCallback(null, response);
    return response;
}
async function handler(event, _context, callback) {
    lambdaCallback = callback;
    try {
        if (factory_1.isSupportedHTTPLambdaRequest(event)) {
            if (!env_1.API_SECRET)
                throw new Error("API_SECRET is required for api calls");
            if (event.headers["Authorization"] !== `Bearer ${env_1.API_SECRET}`)
                return sendResponse("Bad Request", 400);
        }
        const workflow = factory_1.getWorkflow(event);
        if (!workflow)
            return sendResponse("Unsupported event", 400);
        const workflowState = workflow.getExecutionState();
        if (!workflowState)
            return sendResponse("Unsupported state", 400);
        const data = await workflow.getSlackMessageData();
        if (!data) {
            console.log(`Workflow data not found.\nEvent:\n${JSON.stringify(event)}`);
            return sendResponse("Workflow data not found", 404);
        }
        const contextRef = `\`${workflow.getBranchRef()}\` of *${env_1.REPO.name}* to *${env_1.ENV}*`;
        const [color, getStatusText] = STATE_MESSAGES[workflowState];
        const statusText = getStatusText(contextRef);
        const ts = Date.now();
        const attachment = Object.assign({ color, ts }, data.messageDetails);
        if (data.isSaved === false) {
            const messageRef = await slack.callApi("chat.postMessage", {
                channel: env_1.SLACK_CONFIG.channel,
                text: statusText,
                attachments: [attachment],
            });
            await aws.saveItem(await workflow.getExecutionId(), Object.assign(Object.assign({}, data), { isSaved: true, slackMessageRef: { channel: messageRef.channel, ts: messageRef.ts } }));
        }
        else {
            await slack.callApi("chat.update", {
                channel: data.slackMessageRef.channel,
                text: statusText,
                ts: data.slackMessageRef.ts,
                attachments: [attachment],
            });
            if (workflowState === constants_1.WorkflowState.failed) {
                // Post a second message if the flow failed
                const ref = data.slackMessageRef;
                await slack.callApi("chat.postMessage", {
                    channel: env_1.SLACK_CONFIG.channel,
                    attachments: [
                        {
                            color,
                            text: statusText,
                            footer: `<https://${env_1.SLACK_CONFIG.url}/archives/${ref.channel}/p${ref.ts.replace(".", "")}|See details>`,
                            ts,
                        },
                    ],
                });
            }
            if (ENDING_STATES.includes(workflowState)) {
                await aws.removeItem(data.executionId);
            }
        }
        return sendResponse("ok", 204);
    }
    catch (error) {
        console.error(error);
        return sendResponse("Internal server error", 500);
    }
}
exports.handler = handler;
exports.__test__ = {
    handler,
    STATE_MESSAGES,
};
