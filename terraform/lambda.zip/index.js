"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws = __importStar(require("./aws"));
const slack = __importStar(require("./slack"));
const constants_1 = require("./constants");
const env_1 = require("./env");
const factory_1 = require("./workflows/factory");
let lambdaCallback = undefined;
const context = `\`${env_1.REPO.branch}\` of ${env_1.REPO.name} to *${env_1.ENV}*`;
// prettier-ignore
const STATE_MESSAGES = {
    started: [constants_1.COLORS.normal, `Started deploying ${context}`],
    preMigration: [constants_1.COLORS.info, `Started deploying ${context} (Pre-migrations)`],
    deploying: [constants_1.COLORS.info, `Started deploying ${context} (Updating servers)`],
    waitingForStabilization: [constants_1.COLORS.info, `Started deploying ${context} (Waiting for stabilization)`],
    postMigration: [constants_1.COLORS.info, `Started deploying ${context} (Post-migrations)`],
    finished: [constants_1.COLORS.success, `*Finished* deploying ${context}`],
    stopped: [constants_1.COLORS.error, `Deployment *stopped* for ${context}`],
    failed: [constants_1.COLORS.error, `Deployment *failed* for ${context}`],
};
function sendResponse(message, statusCode) {
    const response = {
        statusCode,
        body: message,
        headers: { "Content-Type": "text/html; charset=utf-8" },
        isBase64Encoded: false,
    };
    lambdaCallback === null || lambdaCallback === void 0 ? void 0 : lambdaCallback(null, response);
    return response;
}
async function handler(event, _context, callback) {
    lambdaCallback = callback;
    try {
        if (factory_1.isSupportedHTTPLambdaRequest(event)) {
            if (!env_1.API_SECRET)
                throw new Error("API_SECRET is required for api calls");
            if (event.headers["Authorization"] !== `Bearer ${env_1.API_SECRET}`)
                return sendResponse("Unauthorized", 401);
        }
        const workflow = factory_1.getWorkflow(event);
        if (!workflow)
            return sendResponse("Unsupported event", 400);
        const pipelineState = workflow.getExecutionState();
        if (!pipelineState)
            return sendResponse("Unsupported state", 400);
        const pipelineData = await workflow.getSlackMessageData();
        if (!pipelineData) {
            console.log(`PipelineData not found.\nEvent:\n${JSON.stringify(event)}`);
            return sendResponse("PipelineData not found", 404);
        }
        const [color, statusText] = STATE_MESSAGES[pipelineState];
        const attachment = Object.assign({ color }, pipelineData.messageDetails);
        if (pipelineState === constants_1.PipelineState.started) {
            const slackResponse = await slack.callApi("chat.postMessage", {
                channel: env_1.SLACK_CHANNEL,
                text: statusText,
                attachments: [attachment],
            });
            await aws.savePipelineData(await workflow.getExecutionId(), Object.assign(Object.assign({}, pipelineData), { initialSlackMessageRef: {
                    channel: slackResponse.channel,
                    ts: slackResponse.ts,
                } }));
        }
        else {
            const endingStates = [constants_1.PipelineState.finished, constants_1.PipelineState.stopped, constants_1.PipelineState.failed];
            if (pipelineData.initialSlackMessageRef) {
                await slack.callApi("chat.update", {
                    channel: pipelineData.initialSlackMessageRef.channel,
                    ts: pipelineData.initialSlackMessageRef.ts,
                    text: endingStates.includes(pipelineState) ? STATE_MESSAGES.started[1] : statusText,
                    attachments: [attachment],
                });
            }
            if (endingStates.includes(pipelineState)) {
                const ref = pipelineData.initialSlackMessageRef;
                await slack.callApi("chat.postMessage", {
                    channel: env_1.SLACK_CHANNEL,
                    attachments: [
                        {
                            color,
                            text: statusText,
                            footer: ref
                                ? `<https://${env_1.SLACK_URL}/archives/${ref.channel}/p${ref.ts.replace(".", "")}|See details>`
                                : null,
                            ts: Date.now(),
                        },
                    ],
                });
                await aws.clearPipelineData(pipelineData.executionId);
            }
        }
        return sendResponse("ok", 204);
    }
    catch (error) {
        console.error(error);
        return sendResponse("Internal server error", 500);
    }
}
exports.handler = handler;
exports.__test__ = {
    handler,
    STATE_MESSAGES,
};
