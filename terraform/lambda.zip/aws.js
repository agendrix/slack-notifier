"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.findPipelineExecutionId = exports.getPipelineState = exports.listPipelineActionExecutions = exports.clearPipelineData = exports.savePipelineData = exports.savePipelines = exports.loadPipelines = exports.getLatestDeployedCommitShaFromECR = exports.getPipelineCommitSha = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const env_1 = require("./env");
const PIPELINES_S3_FILENAME = "pipelines.json";
async function getPipelineCommitSha(event) {
    var _a, _b, _c;
    const codePipeline = new aws_sdk_1.default.CodePipeline();
    try {
        const params = {
            pipelineExecutionId: event.detail["execution-id"],
            pipelineName: event.detail.pipeline,
        };
        const response = await codePipeline.getPipelineExecution(params).promise();
        return (_c = (_b = (_a = response.pipelineExecution) === null || _a === void 0 ? void 0 : _a.artifactRevisions) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.revisionId;
    }
    catch (error) {
        if (error.errorType === "PipelineExecutionNotFoundException") {
            await clearPipelineData(event.detail["execution-id"]);
        }
        throw error;
    }
}
exports.getPipelineCommitSha = getPipelineCommitSha;
async function getLatestDeployedCommitShaFromECR(ecrRefRepository) {
    const ecr = new aws_sdk_1.default.ECR();
    const response = await ecr
        .listImages({
        repositoryName: ecrRefRepository,
    })
        .promise();
    const images = response.imageIds;
    if (!images || images.length === 0) {
        return undefined;
    }
    else {
        const latestImage = images.find(e => e.imageTag === "latest");
        if (!latestImage)
            return undefined;
        const latestImageWithCommitTag = images.find(e => e.imageDigest === latestImage.imageDigest && e.imageTag !== "latest");
        if (!latestImageWithCommitTag)
            return undefined;
        return latestImageWithCommitTag.imageTag;
    }
}
exports.getLatestDeployedCommitShaFromECR = getLatestDeployedCommitShaFromECR;
async function loadPipelines() {
    const s3 = new aws_sdk_1.default.S3();
    try {
        const response = await s3
            .getObject({
            Bucket: env_1.S3_BUCKET,
            Key: `${env_1.S3_KEY}/${PIPELINES_S3_FILENAME}`,
        })
            .promise();
        if (!response.Body)
            return {};
        try {
            return JSON.parse(response.Body.toString());
        }
        catch (error) {
            return {};
        }
    }
    catch (error) {
        if (error.code === "NoSuchKey") {
            return {};
        }
        else {
            throw error;
        }
    }
}
exports.loadPipelines = loadPipelines;
async function savePipelines(pipelines) {
    const s3 = new aws_sdk_1.default.S3();
    await s3
        .upload({
        Bucket: env_1.S3_BUCKET,
        Key: `${env_1.S3_KEY}/${PIPELINES_S3_FILENAME}`,
        Body: JSON.stringify(pipelines),
    })
        .promise();
}
exports.savePipelines = savePipelines;
async function savePipelineData(executionId, data) {
    const pipelines = await loadPipelines();
    pipelines[executionId] = data;
    await savePipelines(pipelines);
}
exports.savePipelineData = savePipelineData;
async function clearPipelineData(executionId) {
    const pipelines = await loadPipelines();
    delete pipelines[executionId];
    await savePipelines(pipelines);
}
exports.clearPipelineData = clearPipelineData;
async function listPipelineActionExecutions(pipelineName, pipelineExecutionId) {
    const codePipeline = new aws_sdk_1.default.CodePipeline();
    try {
        const response = await codePipeline
            .listActionExecutions({
            pipelineName,
            filter: { pipelineExecutionId },
        })
            .promise();
        return response.actionExecutionDetails || [];
    }
    catch (error) {
        if (error.errorType === "PipelineExecutionNotFoundException") {
            await clearPipelineData(pipelineExecutionId);
        }
        return [];
    }
}
exports.listPipelineActionExecutions = listPipelineActionExecutions;
function getPipelineState(pipelineName) {
    const codePipeline = new aws_sdk_1.default.CodePipeline();
    return codePipeline.getPipelineState({ name: pipelineName }).promise();
}
exports.getPipelineState = getPipelineState;
async function findPipelineExecutionId(pipelineName, pipelines, codeDeployExecutionId) {
    console.log("Searching Pipeline ExecutionId...");
    for (const pipeline of Object.values(pipelines)) {
        const actionExecutions = await listPipelineActionExecutions(pipelineName, pipeline.executionId);
        console.log("codeDeployExecutionId", codeDeployExecutionId);
        if (JSON.stringify(actionExecutions).includes(codeDeployExecutionId)) {
            console.log("Found in actions");
            return pipeline.executionId;
        }
    }
    // If the codeDeployExecutionId is not found in the actionExecutions history,
    // we must search the current execution.
    const currentPipelineState = await getPipelineState(pipelineName);
    const stageStates = currentPipelineState.stageStates || [];
    for (const stage of stageStates) {
        if (!stage.latestExecution || !stage.actionStates)
            continue;
        for (const action of stage.actionStates) {
            if (action.latestExecution && action.latestExecution.externalExecutionId === codeDeployExecutionId) {
                console.log("Found in current pipeline");
                return stage.latestExecution.pipelineExecutionId;
            }
        }
    }
    console.log("Not found");
    return undefined;
}
exports.findPipelineExecutionId = findPipelineExecutionId;
